package flowtimer;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class VariableComponent<E extends JComponent> {
	
	public static final int X_BASE = 150;
	public static final int X_OFFSET = 50;
	public static final int Y_BASE = 20;
	public static final int Y_PADDING = 25;

	private JLabel label;
	private E component;
	
	public VariableComponent(int index, String name, E component, int width, int height) {
		int y = Y_BASE + index * Y_PADDING;
		label = new JLabel(name + ":");
		label.setBounds(X_BASE, y, X_OFFSET - 5, 35);
		this.component = component;
		component.setBounds(X_BASE + X_OFFSET, y + (35 - height) / 2, width, height);
	}
	
	public void add(JPanel parent) {
		parent.add(label);
		parent.add(component);
	}
	
	public void setEnabled(boolean enabled) {
		component.setEnabled(enabled);
	}

	public JLabel getLabel() {
		return label;
	}

	public E getComponent() {
		return component;
	}
}
