package flowtimer;

import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.UIManager;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.jnativehook.GlobalScreen;

import flowtimer.parsing.Config;
import flowtimer.parsing.json.JSON;
import flowtimer.parsing.json.JSONArray;
import flowtimer.parsing.json.JSONObject;
import flowtimer.parsing.json.JSONValue;

public class FlowTimer {

	public static final int WIDTH = 451;
	public static final int HEIGHT = 287;
	public static final String TITLE = "FlowTimer 1.5";

	public static final int FIXED_OFFSET = 0;
	public static final int VARIABLE_OFFSET = 1;

	public static final int ADD_BUTTON_BASE_X = 146;
	public static final int ADD_BUTTON_BASE_Y = 35;
	public static final int ADD_BUTTON_WIDTH = 55;
	public static final int ADD_BUTTON_HEIGHT = 22;
	public static final int ADD_BUTTON_PADDING = 3;

	public static final String SETTINGS_FILE_LOCATION = System.getenv("appdata") + "\\flowtimer.config";
	public static final File SETTINGS_FILE = new File(SETTINGS_FILE_LOCATION);
	public static final HashMap<String, Integer> BEEP_MAP = new HashMap<>();

	private static LinkedList<Timer> timers = new LinkedList<>();
	private static Timer activeTimer;
	private static Timer selectedTimer;
	private static ScheduledExecutorService scheduler;
	private static ScheduledFuture<?>[] beepFutures;
	private static TimerLabelUpdateThread timerLabelUpdateThread;
	private static VisualCueThread visualCueThread;
	private static boolean isTimerRunning;
	private static boolean areBeepsScheduled;
	private static long timerStartTime;
	private static int beepSound;
	private static int visualCueLength;

	private static JFrame frame;
	private static JPanel fixedOffsetPanel;
	private static JPanel variableOffsetPanel;
	private static JTabbedPane tabbedPane;

	private static JLabel timerLabel;
	private static VisualCuePanel visualCuePanel;
	private static MenuButton startButton;
	private static MenuButton resetButton;
	private static MenuButton settingsButton;
	private static JLabel pinLabel;

	private static MenuButton loadTimersButton;
	private static MenuButton saveTimersButton;
	private static MenuButton saveTimersAsButton;
	private static JButton addButton;
	private static ColumnLabel nameLabel;
	private static ColumnLabel offsetLabel;
	private static ColumnLabel intervalLabel;
	private static ColumnLabel numBeepsLabel;

	private static VariableComponent<IntTextField> frameComponent;
	private static VariableComponent<JComboBox<Float>> fpsComponent;
	private static VariableComponent<IntTextField> offsetComponent;
	private static VariableComponent<IntTextField> intervalComponent;
	private static VariableComponent<IntTextField> numBeepsComponent;
	private static JButton submitButton;

	private static String fileSystemLocationBuffer;
	private static String timerLocationBuffer;

	static {
		OpenAL.init();
		BEEP_MAP.put("ping1", OpenAL.createSource("/audio/ping1.wav"));
		BEEP_MAP.put("ping2", OpenAL.createSource("/audio/ping2.wav"));
		BEEP_MAP.put("clack", OpenAL.createSource("/audio/clack.wav"));
		BEEP_MAP.put("click1", OpenAL.createSource("/audio/click1.wav"));
		BEEP_MAP.put("clap", OpenAL.createSource("/audio/clap.wav"));
		BEEP_MAP.put("beep", OpenAL.createSource("/audio/beep.wav"));
	}

	public static void main(String args[]) {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
			e.printStackTrace();
		}

		frame = new JFrame();
		pinLabel = new JLabel();
		SettingsWindow.create(frame);

		fixedOffsetPanel = new JPanel();
		fixedOffsetPanel.setLayout(null);

		variableOffsetPanel = new JPanel();
		variableOffsetPanel.setLayout(null);

		frameComponent = new VariableComponent<IntTextField>(0, "Frame", new IntTextField(false), 80, 20);
		fpsComponent = new VariableComponent<JComboBox<Float>>(1, "FPS", new JComboBox<Float>(new Float[] { 60.0f, 59.7275f, 59.8261f }), 80, 20);
		offsetComponent = new VariableComponent<IntTextField>(2, "Offset", new IntTextField(true), 80, 20);
		intervalComponent = new VariableComponent<IntTextField>(3, "Interval", new IntTextField(false), 80, 20);
		numBeepsComponent = new VariableComponent<IntTextField>(4, "Beeps", new IntTextField(false), 80, 20);

		frameComponent.getComponent().getDocument().addDocumentListener(new VariableElementDocumentListener());
		offsetComponent.getComponent().getDocument().addDocumentListener(new VariableElementDocumentListener());
		intervalComponent.getComponent().getDocument().addDocumentListener(new VariableElementDocumentListener());
		numBeepsComponent.getComponent().getDocument().addDocumentListener(new VariableElementDocumentListener());
		
		submitButton = new JButton("Submit");
		submitButton.setBounds(285, 26, 80, 22);
		submitButton.setEnabled(false);
		submitButton.addActionListener(e -> {
			setVariableInterface(false);
			long offsets[] = { getVariableOffset() - timerLabelUpdateThread.updateCallback.getTime() };
			long interval = intervalComponent.getComponent().getValue();
			int numBeeps = numBeepsComponent.getComponent().getValue();
			long globalOffset = offsetComponent.getComponent().getValue();
			long beeps[][] = Timer.calcBeeps(offsets, interval, numBeeps, globalOffset);
			startBeeps(offsets, beeps, numBeeps, interval);
			submitButton.setEnabled(false);
		});

		try {
			Logger logger = Logger.getLogger(GlobalScreen.class.getPackage().getName());
			logger.setLevel(Level.OFF);
			logger.setUseParentHandlers(false);

			GlobalScreen.registerNativeHook();
			GlobalScreen.addNativeKeyListener(new GlobalScreenListener());

			HashMap<String, String> defaultMap = new HashMap<>();
			defaultMap.put("fileSystemLocationBuffer", System.getProperty("user.home") + "\\Desktop");
			defaultMap.put("timerLocationBuffer", "null");

			defaultMap.put("primaryStartKey", "-1");
			defaultMap.put("primaryStartKeyName", "Unset");
			defaultMap.put("primaryResetKey", "-1");
			defaultMap.put("primaryResetKeyName", "Unset");
			defaultMap.put("primaryUpKey", "57416");
			defaultMap.put("primaryUpKeyName", "Up");
			defaultMap.put("primaryDownKey", "57424");
			defaultMap.put("primaryDownKeyName", "Down");

			defaultMap.put("secondaryStartKey", "-1");
			defaultMap.put("secondaryStartKeyName", "Unset");
			defaultMap.put("secondaryResetKey", "-1");
			defaultMap.put("secondaryResetKeyName", "Unset");
			defaultMap.put("secondaryUpKey", "-1");
			defaultMap.put("secondaryUpKeyName", "Unset");
			defaultMap.put("secondaryDownKey", "-1");
			defaultMap.put("secondaryDownKeyName", "Unset");

			defaultMap.put("globalStartReset", "true");
			defaultMap.put("globalUpDown", "true");
			defaultMap.put("visualCue", "false");
			defaultMap.put("beepSound", "ping1");

			defaultMap.put("visualCueLength", "20");
			defaultMap.put("pin", "false");

			defaultMap.put("key", "On Press");

			defaultMap.put("variableFps", "60.0");
			defaultMap.put("variableOffset", "0");
			defaultMap.put("variableInterval", "500");
			defaultMap.put("variableNumBeeps", "5");

			Config config;
			if(!SETTINGS_FILE.exists()) {
				config = new Config(defaultMap);
				config.write(SETTINGS_FILE_LOCATION);
			} else {
				config = new Config(SETTINGS_FILE_LOCATION);
			}
			fileSystemLocationBuffer = config.getStringWithDefault("fileSystemLocationBuffer", defaultMap.get("fileSystemLocationBuffer"));
			timerLocationBuffer = config.getStringWithDefault("timerLocationBuffer", defaultMap.get("timerLocationBuffer"));

			visualCueLength = config.getIntWithDefault("visualCueLength", defaultMap.get("visualCueLength"));

			SettingsWindow.getStartInput().getPrimaryInput().set(config.getStringWithDefault("primaryStartKeyName", defaultMap.get("primaryStartKeyName")), config.getIntWithDefault("primaryStartKey", defaultMap.get("primaryStartKey")));
			SettingsWindow.getResetInput().getPrimaryInput().set(config.getStringWithDefault("primaryResetKeyName", defaultMap.get("primaryResetKeyName")), config.getIntWithDefault("primaryResetKey", defaultMap.get("primaryResetKey")));
			SettingsWindow.getUpInput().getPrimaryInput().set(config.getStringWithDefault("primaryUpKeyName", defaultMap.get("primaryUpKeyName")), config.getIntWithDefault("primaryUpKey", defaultMap.get("primaryUpKey")));
			SettingsWindow.getDownInput().getPrimaryInput().set(config.getStringWithDefault("primaryDownKeyName", defaultMap.get("primaryDownKeyName")), config.getIntWithDefault("primaryDownKey", defaultMap.get("primaryDownKey")));

			SettingsWindow.getStartInput().getSecondaryInput().set(config.getStringWithDefault("secondaryStartKeyName", defaultMap.get("secondaryStartKeyName")), config.getIntWithDefault("secondaryStartKey", defaultMap.get("secondaryStartKey")));
			SettingsWindow.getResetInput().getSecondaryInput().set(config.getStringWithDefault("secondaryResetKeyName", defaultMap.get("secondaryResetKeyName")), config.getIntWithDefault("secondaryResetKey", defaultMap.get("secondaryResetKey")));
			SettingsWindow.getUpInput().getSecondaryInput().set(config.getStringWithDefault("secondaryUpKeyName", defaultMap.get("secondaryUpKeyName")), config.getIntWithDefault("secondaryUpKey", defaultMap.get("secondaryUpKey")));
			SettingsWindow.getDownInput().getSecondaryInput().set(config.getStringWithDefault("secondaryDownKeyName", defaultMap.get("secondaryDownKeyName")), config.getIntWithDefault("secondaryDownKey", defaultMap.get("secondaryDownKey")));

			SettingsWindow.getGlobalStartReset().setSelected(config.getBooleanWithDefault("globalStartReset", defaultMap.get("globalStartReset")));
			SettingsWindow.getGlobalUpDown().setSelected(config.getBooleanWithDefault("globalUpDown", defaultMap.get("globalUpDown")));
			SettingsWindow.getVisualCue().setSelected(config.getBooleanWithDefault("visualCue", defaultMap.get("visualCue")));
			SettingsWindow.getBeepSound().setSelectedItem(config.getStringWithDefault("beepSound", defaultMap.get("beepSound")));
			SettingsWindow.getKeyTrigger().setSelectedItem(config.getStringWithDefault("key", defaultMap.get("key")));

			setPin(config.getBooleanWithDefault("pin", defaultMap.get("pin")));

			fpsComponent.getComponent().setSelectedItem((float) config.getDoubleWithDefault("variableFps", defaultMap.get("variableFps")));
			offsetComponent.getComponent().setText(config.getStringWithDefault("variableOffset", defaultMap.get("variableOffset")));
			intervalComponent.getComponent().setText(config.getStringWithDefault("variableInterval", defaultMap.get("variableInterval")));
			numBeepsComponent.getComponent().setText(config.getStringWithDefault("variableNumBeeps", defaultMap.get("variableNumBeeps")));
		} catch (Exception e) {
			ErrorHandler.handleException(e, true);
		}

		frame.setSize(WIDTH, HEIGHT);
		frame.setTitle(TITLE);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.setLayout(null);
		frame.setIconImage(ImageLoader.loadImage("/image/icon.png").getImage());
		frame.setVisible(true);

		timerLabel = new JLabel();
		timerLabel.setBounds(11, 20, 120, 30);
		timerLabel.setFont(new Font("Consolas", Font.BOLD, 29));

		pinLabel.setBounds(413, 5, 16, 16);
		pinLabel.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				setPin(!frame.isAlwaysOnTop());
			}
		});

		visualCuePanel = new VisualCuePanel(frame);

		addButton = new JButton("Add");
		addButton.setSize(ADD_BUTTON_WIDTH, ADD_BUTTON_HEIGHT);

		startButton = new MenuButton("Start", 0);
		resetButton = new MenuButton("Reset", 1);
		settingsButton = new MenuButton("Settings", 2);
		loadTimersButton = new MenuButton("Load Timers", 3);
		saveTimersButton = new MenuButton("Save Timers", 4);
		saveTimersAsButton = new MenuButton("Save Timers As", 5);

		nameLabel = new ColumnLabel("Name", 0);
		offsetLabel = new ColumnLabel("Offset", 1);
		intervalLabel = new ColumnLabel("Interval", 2);
		numBeepsLabel = new ColumnLabel("Beeps", 3);

		addButton.addActionListener(e -> addDefaultTimer(true));

		scheduler = Executors.newScheduledThreadPool(2);
		beepFutures = new ScheduledFuture[0];
		visualCueThread = new VisualCueThread();

		startButton.addActionListener(e -> onStartButtonPress());
		resetButton.addActionListener(e -> onResetButtonPress());
		loadTimersButton.addActionListener(e -> onLoadTimersPress());
		saveTimersButton.addActionListener(e -> onSaveTimersPress());
		saveTimersAsButton.addActionListener(e -> onSaveTimersAsPress());
		settingsButton.addActionListener(e -> SettingsWindow.show());

		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				OpenAL.dispose();

				HashMap<String, String> map = new HashMap<>();
				map.put("fileSystemLocationBuffer", fileSystemLocationBuffer);
				map.put("timerLocationBuffer", timerLocationBuffer);

				map.put("primaryStartKey", SettingsWindow.getStartInput().getPrimaryInput().getKeyCode() + "");
				map.put("primaryResetKey", SettingsWindow.getResetInput().getPrimaryInput().getKeyCode() + "");
				map.put("primaryUpKey", SettingsWindow.getUpInput().getPrimaryInput().getKeyCode() + "");
				map.put("primaryDownKey", SettingsWindow.getDownInput().getPrimaryInput().getKeyCode() + "");
				map.put("primaryStartKeyName", SettingsWindow.getStartInput().getPrimaryInput().getName());
				map.put("primaryResetKeyName", SettingsWindow.getResetInput().getPrimaryInput().getName());
				map.put("primaryUpKeyName", SettingsWindow.getUpInput().getPrimaryInput().getName());
				map.put("primaryDownKeyName", SettingsWindow.getDownInput().getPrimaryInput().getName());

				map.put("secondaryStartKey", SettingsWindow.getStartInput().getSecondaryInput().getKeyCode() + "");
				map.put("secondaryResetKey", SettingsWindow.getResetInput().getSecondaryInput().getKeyCode() + "");
				map.put("secondaryUpKey", SettingsWindow.getUpInput().getSecondaryInput().getKeyCode() + "");
				map.put("secondaryDownKey", SettingsWindow.getDownInput().getSecondaryInput().getKeyCode() + "");
				map.put("secondaryStartKeyName", SettingsWindow.getStartInput().getSecondaryInput().getName());
				map.put("secondaryResetKeyName", SettingsWindow.getResetInput().getSecondaryInput().getName());
				map.put("secondaryUpKeyName", SettingsWindow.getUpInput().getSecondaryInput().getName());
				map.put("secondaryDownKeyName", SettingsWindow.getDownInput().getSecondaryInput().getName());

				map.put("globalStartReset", SettingsWindow.getGlobalStartReset().isSelected() + "");
				map.put("globalUpDown", SettingsWindow.getGlobalUpDown().isSelected() + "");
				map.put("visualCue", SettingsWindow.getVisualCue().isSelected() + "");
				map.put("beepSound", SettingsWindow.getBeepSound().getSelectedItem() + "");

				map.put("visualCueLength", visualCueLength + "");
				map.put("pin", frame.isAlwaysOnTop() + "");
				map.put("key", SettingsWindow.getKeyTrigger().getSelectedItem() + "");

				map.put("variableFps", fpsComponent.getComponent().getSelectedItem() + "");
				if(offsetComponent.getComponent().isValidInt()) {
					map.put("variableOffset", offsetComponent.getComponent().getValue() + "");
				}
				if(intervalComponent.getComponent().isValidInt()) {
					map.put("variableInterval", intervalComponent.getComponent().getValue() + "");
				}
				if(numBeepsComponent.getComponent().isValidInt()) {
					map.put("variableNumBeeps", numBeepsComponent.getComponent().getValue() + "");
				}

				Config config = new Config(map);
				try {
					config.write(SETTINGS_FILE_LOCATION);
				} catch (Exception e1) {
					ErrorHandler.handleException(e1, false);
				}
			}
		});

		fixedOffsetPanel.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				requestFocus();
			}
		});

		if(!new File(timerLocationBuffer).exists()) {
			if(!timerLocationBuffer.equals("null")) {
				JOptionPane.showMessageDialog(frame, "Unable to load the latest timer file.");
				timerLocationBuffer = "null";
			}
			addDefaultTimer(false);
		} else {
			loadTimers(timerLocationBuffer, false);
		}

		fixedOffsetPanel.add(timerLabel);
		fixedOffsetPanel.add(startButton);
		fixedOffsetPanel.add(resetButton);
		fixedOffsetPanel.add(settingsButton);
		fixedOffsetPanel.add(loadTimersButton);
		fixedOffsetPanel.add(saveTimersButton);
		fixedOffsetPanel.add(saveTimersAsButton);
		fixedOffsetPanel.add(pinLabel);
		fixedOffsetPanel.add(nameLabel);
		fixedOffsetPanel.add(offsetLabel);
		fixedOffsetPanel.add(intervalLabel);
		fixedOffsetPanel.add(numBeepsLabel);
		fixedOffsetPanel.add(addButton);
		fixedOffsetPanel.add(pinLabel);
		fixedOffsetPanel.add(visualCuePanel);

		frameComponent.add(variableOffsetPanel);
		fpsComponent.add(variableOffsetPanel);
		offsetComponent.add(variableOffsetPanel);
		intervalComponent.add(variableOffsetPanel);
		numBeepsComponent.add(variableOffsetPanel);
		variableOffsetPanel.add(submitButton);

		tabbedPane = new JTabbedPane();
		tabbedPane.addTab("Fixed Offset", fixedOffsetPanel);
		tabbedPane.addTab("Variable Offset", variableOffsetPanel);
		tabbedPane.setBounds(0, 0, WIDTH, HEIGHT);
		tabbedPane.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				// Biggest hack of all time
				JPanel panel = tabbedPane.getSelectedIndex() == 0 ? fixedOffsetPanel : variableOffsetPanel;
				panel.add(timerLabel);
				panel.add(startButton);
				panel.add(resetButton);
				panel.add(settingsButton);
				panel.add(pinLabel);
				panel.add(visualCuePanel);
				if(tabbedPane.getSelectedIndex() == FIXED_OFFSET) {
					panel.add(loadTimersButton);
					panel.add(saveTimersButton);
					panel.add(saveTimersAsButton);
					selectedTimer.select();
				} else if(tabbedPane.getSelectedIndex() == VARIABLE_OFFSET) {
					setTimerLabel(0);
				}
			}
		});

		frame.add(tabbedPane);
		frame.repaint();
	}

	public static void onStartButtonPress() {
		startTimer();
	}

	public static void onResetButtonPress() {
		if(isTimerRunning) {
			stopTimer();
			if(tabbedPane.getSelectedIndex() == FIXED_OFFSET) {
				setTimerLabel(selectedTimer.getMaxOffset());
			}
		}
	}

	public static void onUpKeyPress() {
		changeTimer(-1);
	}

	public static void onDownKeyPress() {
		changeTimer(+1);
	}

	public static void changeTimer(int amount) {
		int currentIndex = timers.indexOf(selectedTimer);
		currentIndex += amount;
		currentIndex = Math.floorMod(currentIndex, timers.size());
		timers.get(currentIndex).select();
	}

	public static void startTimer() {
		if(tabbedPane.getSelectedIndex() == FIXED_OFFSET) {
			if(selectedTimer != null) {
				if(isTimerRunning) {
					stopTimer();
				}
				isTimerRunning = true;
				Timer t = selectedTimer;
				activeTimer = selectedTimer;
				timerStartTime = System.nanoTime();
				startBeeps(t.getOffsets(), t.getBeeps(), t.getNumBeeps(), t.getInterval());
				setInterface(false);
				timerLabelUpdateThread = new TimerLabelUpdateThread(() -> activeTimer.getMaxOffset() - (System.nanoTime() - timerStartTime) / 1_000_000);
				new Thread(timerLabelUpdateThread).start();
			}
		} else if(tabbedPane.getSelectedIndex() == VARIABLE_OFFSET) {
			if(isTimerRunning) {
				stopTimer();
			}
			timerStartTime = System.nanoTime();
			setInterface(false);
			isTimerRunning = true;
			timerLabelUpdateThread = new TimerLabelUpdateThread(() -> (System.nanoTime() - timerStartTime) / 1_000_000);
			new Thread(timerLabelUpdateThread).start();
		}
	}

	private static void startBeeps(long offsets[], long beeps[][], int numBeeps, long interval) {
		beepFutures = new ScheduledFuture[offsets.length];
		for(int i = 0; i < offsets.length; i++) {
			BeepThread beepThread = new BeepThread(i, i == offsets.length - 1, numBeeps);
			beepFutures[i] = scheduler.scheduleAtFixedRate(beepThread, beeps[i][0] * 1_000_000, interval * 1_000_000, TimeUnit.NANOSECONDS);
		}
		areBeepsScheduled = true;
	}

	public static void stopTimer() {
		for(ScheduledFuture<?> future : beepFutures) {
			future.cancel(false);
		}
		isTimerRunning = false;
		areBeepsScheduled = false;
		timerLabelUpdateThread.stop();
		setInterface(true);
		setVariableInterface(true);
		setTimerLabel(0);
	}

	public static void stopSegment(int index) {
		beepFutures[index].cancel(false);
	}

	public static void addNewTimer(String name, String offset, long interval, int numBeeps, boolean addRemoveButton) {
		addNewTimer(new Timer(timers.size(), name, offset, interval, numBeeps, addRemoveButton));
	}

	public static void addNewTimer(Timer timer) {
		timers.add(timer);
		timer.addAllElements(fixedOffsetPanel);
		timer.select();
		recalcAddButton();
		frame.repaint();
	}

	public static void removeTimer(Timer timer) {
		timers.remove(timer);
		timer.removeAllElements(fixedOffsetPanel);
		for(Timer t : timers) {
			t.recalcPosition(timers.indexOf(t));
		}
		if(timers.size() > 0) {
			timers.get(0).select();
		}
		recalcAddButton();
		frame.repaint();
	}

	public static void onSaveTimersPress() {
		if(timerLocationBuffer.equals("null")) {
			onSaveTimersAsPress();
		} else {
			saveTimers(timerLocationBuffer);
		}
	}

	public static void onSaveTimersAsPress() {
		JFileChooser fileChooser = new JFileChooser(fileSystemLocationBuffer);
		fileChooser.setDialogTitle("Save Timers");
		int result = fileChooser.showSaveDialog(frame);
		fileSystemLocationBuffer = fileChooser.getCurrentDirectory().getAbsolutePath();
		if(result == JFileChooser.APPROVE_OPTION) {
			String filePath = fileChooser.getSelectedFile().getAbsolutePath();
			if(!filePath.toLowerCase().endsWith(".json")) {
				filePath += ".json";
			}
			saveTimers(filePath);
		}
	}

	public static void saveTimers(String filePath) {
		JSONArray array = new JSONArray();
		for(Timer timer : timers) {
			JSONObject object = new JSONObject();
			object.put("name", timer.getName());
			object.put("offsets", timer.getOffsetsString());
			object.put("interval", timer.getInterval());
			object.put("numBeeps", timer.getNumBeeps());
			object.put("removeButton", timer.hasRemoveButton());
			array.add(object);
		}
		JSON json = new JSON(array);
		json.write(filePath);
		timerLocationBuffer = filePath;
		JOptionPane.showMessageDialog(null, "Timers successfully saved to " + filePath, "Success", JOptionPane.INFORMATION_MESSAGE);
	}

	public static void onLoadTimersPress() {
		JFileChooser fileChooser = new JFileChooser(fileSystemLocationBuffer);
		fileChooser.setDialogTitle("Load Timers");
		fileChooser.setFileFilter(new FileNameExtensionFilter(".json files", "json"));
		int result = fileChooser.showOpenDialog(frame);
		fileSystemLocationBuffer = fileChooser.getCurrentDirectory().getAbsolutePath();
		if(result == JFileChooser.APPROVE_OPTION) {
			String filePath = fileChooser.getSelectedFile().getAbsolutePath();
			loadTimers(filePath, true);
		}
	}

	public static void loadTimers(String filePath, boolean showSuccessMessage) {
		LinkedList<Timer> loadedList = new LinkedList<>();
		try {
			List<JSONValue> jsonTimers = new JSON(new File(filePath)).get().asArray();
			int index = 0;
			for(JSONValue jsonTimer : jsonTimers) {
				Map<String, JSONValue> timer = jsonTimer.asObject();
				loadedList.add(new Timer(index++, timer.get("name").asString(), timer.get("offsets").asString(), timer.get("interval").asLong(), timer.get("numBeeps").asInt(), timer.get("removeButton").asBoolean()));
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Timers failed to load.", "Error", JOptionPane.ERROR_MESSAGE);
			return;
		}
		LinkedList<Timer> currentTimers = new LinkedList<>(timers);
		currentTimers.forEach(timer -> removeTimer(timer));
		loadedList.forEach(timer -> addNewTimer(timer));
		timers.getFirst().select();
		timerLocationBuffer = filePath;
		if(showSuccessMessage) {
			JOptionPane.showMessageDialog(null, "Timers successfully loaded.", "Success", JOptionPane.INFORMATION_MESSAGE);
		}
	}

	public static Timer getTimer(int index) {
		return timers.get(index);
	}

	public static Timer getLastTimer() {
		return timers.get(timers.size() - 1);
	}

	public static Timer getSelectedTimer() {
		return selectedTimer;
	}

	public static void setSelectedTimer(Timer selectedTimer) {
		FlowTimer.selectedTimer = selectedTimer;
	}

	public static void setTimerLabel(String text) {
		timerLabel.setText(text);
	}

	public static void setTimerLabel(long time) {
		timerLabel.setText(String.format(Locale.ENGLISH, "%.3f", ((double) time / 1000.0)));
	}

	public static boolean isFocused() {
		return frame.isActive();
	}

	public static int getBeepSound() {
		return beepSound;
	}

	public static int getSelectedTab() {
		return tabbedPane.getSelectedIndex();
	}

	public static void setBeepSound(int beepSound) {
		FlowTimer.beepSound = beepSound;
	}

	public static void setPin(boolean val) {
		frame.setAlwaysOnTop(val);
		pinLabel.setIcon(ImageLoader.loadImage("/image/pin_" + val + ".png"));
	}

	public static void requestFocus() {
		frame.requestFocusInWindow();
	}

	private static void addDefaultTimer(boolean addRemoveButton) {
		addNewTimer("Timer", "5000", 500, 5, addRemoveButton);
	}

	private static void recalcAddButton() {
		int addButtonX = ADD_BUTTON_BASE_X;
		int addButtonY = ADD_BUTTON_BASE_Y + (addButton.getHeight() + ADD_BUTTON_PADDING) * timers.size();
		addButton.setBounds(addButtonX, addButtonY, addButton.getWidth(), addButton.getHeight());
		frame.setSize(frame.getWidth(), Math.max(HEIGHT, 25 * (timers.size() + 4) + 12));
	}

	private static void setInterface(boolean enabled) {
		timers.forEach(timer -> timer.setElements(enabled));
		saveTimersButton.setEnabled(enabled);
		loadTimersButton.setEnabled(enabled);
		settingsButton.setEnabled(enabled);
		saveTimersAsButton.setEnabled(enabled);
		addButton.setEnabled(enabled);
	}

	private static void setVariableInterface(boolean enabled) {
		fpsComponent.setEnabled(enabled);
		offsetComponent.setEnabled(enabled);
		intervalComponent.setEnabled(enabled);
		numBeepsComponent.setEnabled(enabled);
		frameComponent.setEnabled(enabled);
	}

	private static boolean isVariableDataValid() {
		if(!intervalComponent.getComponent().getText().matches("^0*[1-9]\\d*$")) {
			return false;
		}
		if(!numBeepsComponent.getComponent().getText().matches("^0*[1-9]\\d*$")) {
			return false;
		}
		if(!frameComponent.getComponent().getText().matches("^0*[1-9]\\d*$")) {
			return false;
		}
		if(!offsetComponent.getComponent().getText().matches("^-?\\d+$")) {
			return false;
		}
		if(isTimerRunning) {
			if(getVariableOffset() - (intervalComponent.getComponent().getValue() * numBeepsComponent.getComponent().getValue()) < timerLabelUpdateThread.updateCallback.getTime()) {
				return false;
			}
		}
		return true;
	}

	private static long getVariableOffset() {
		return (long) (Float.parseFloat(frameComponent.getComponent().getText()) / (float) fpsComponent.getComponent().getSelectedItem() * 1000.0f);
	}

	private static class BeepThread implements Runnable {

		private int index;
		private boolean isLast;
		private int numInvocations;
		private int numMaxInvocations;

		public BeepThread(int index, boolean isLast, int numMaxInvocations) {
			this.index = index;
			this.isLast = isLast;
			this.numInvocations = 0;
			this.numMaxInvocations = numMaxInvocations;
		}

		public void run() {
			OpenAL.playSource(beepSound);
			if(SettingsWindow.getVisualCue().isSelected()) {
				new Thread(visualCueThread).start();
			}
			numInvocations++;
			if(numInvocations >= numMaxInvocations) {
				if(isLast) {
					stopTimer();
				} else {
					stopSegment(index);
				}
			}
		}
	}

	private static class VisualCueThread implements Runnable {

		public void run() {
			visualCuePanel.toggleVisualCue();
			try {
				Thread.sleep(visualCueLength);
			} catch (InterruptedException e) {
				ErrorHandler.handleException(e, false);
			}
			visualCuePanel.toggleVisualCue();
		}
	}

	private static class TimerLabelUpdateThread implements Runnable {

		private boolean isStopped;
		private ITimerLabelUpdateCallback updateCallback;

		public TimerLabelUpdateThread(ITimerLabelUpdateCallback updateCallback) {
			this.updateCallback = updateCallback;
		}

		public void run() {
			isStopped = false;
			while(!isStopped) {
				setTimerLabel(updateCallback.getTime());
				submitButton.setEnabled(isTimerRunning && isVariableDataValid() && !areBeepsScheduled);
				try {
					// arbitrary sleep time to lower cpu usage
					Thread.sleep(3);
				} catch (InterruptedException e) {
					ErrorHandler.handleException(e, false);
				}
			}
		}

		public void stop() {
			isStopped = true;
		}
	}

	private static interface ITimerLabelUpdateCallback {

		long getTime();
	}

	private static class VariableElementDocumentListener implements DocumentListener {

		public void insertUpdate(DocumentEvent e) {
			onChange();
		}

		public void removeUpdate(DocumentEvent e) {
			onChange();
		}

		public void changedUpdate(DocumentEvent e) {
			onChange();
		}

		private void onChange() {
			submitButton.setEnabled(isTimerRunning && isVariableDataValid());
		}
	}
}